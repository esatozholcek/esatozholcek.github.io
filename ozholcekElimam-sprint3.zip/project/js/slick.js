$(document).ready(function() {
    $(".slick-carousel").slick({
        autoplay: true,
        autoplaySpeed: 2000,
        dots: true,
        infinite: true,
        speed: 1500,
        slidesToShow: 1,
        arrows: true,
        slidesToScroll: 1
    });

});