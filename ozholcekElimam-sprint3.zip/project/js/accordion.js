$(function() {
    $("#accordion").accordion({
        header: "h3",
        autoHeight: false,
        navigation: true,
        collapsible: true,
        acitive: false
    });
});