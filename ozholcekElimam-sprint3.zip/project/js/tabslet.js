$(document).ready(function() {
    $('.tabs').tabslet({
        mouseevent: 'click',
        attribute: 'href',
        animation: true
    });
});